# Define server
library(plotly)
library(readxl)
server <- function(input, output) {
  data <- read_xls("C:/Users/DanielWade/OneDrive - Suffolk Wildlife Trust/Desktop/AI Shiny App/Species AI Prevalence and Jeffries Intervals.xlsx")
  
  output$graph <- renderPlotly({
    filtered_data <- data %>% filter(Family == input$Family)
    filtered_data$Species_n <- paste(filtered_data$Species, filtered_data$`Species (n)`)
    
    # Calculate the height of the graph based on the number of rows
    num_rows <- nrow(filtered_data)
    graph_height <- 400 + num_rows * 30
    
    p <- ggplot(filtered_data, aes(x = `Percent Positive`, y = `Species (n)`)) +
      geom_errorbar(aes(xmin = `Lower CI`, xmax = `Upper CI`), colour = 'grey') +
      geom_point(aes(x = `Percent Positive`, y = `Species (n)`), color = "red", size = 3) +
      xlim(0, 100) +
      theme_bw() +
      theme(legend.position = 'none') +
      xlab('Proportion positive and Jeffreys Interval') +
      ylab('Species (Number of Samples)') +
      theme(plot.margin = margin(1, 1, 1, 1, "cm"))
    
    # Convert ggplot to plotly
    p <- ggplotly(p, height = graph_height)
    
    # Customize plotly layout
    p <- p %>% layout(margin = list(l = 50, r = 50, b = 50, t = 50))
    
    p
  })
  
  output$table <- renderTable({
    filtered_data <- data %>% filter(Family == input$Family)
    filtered_data$Species <- cell_spec(filtered_data$Species, "html", italic = TRUE)
    filtered_data$`Total Number of Samples` <- format(filtered_data$`Total Number of Samples`, big.mark = ",")
    filtered_data$`Total Number of Positive Samples` <- format(filtered_data$`Total Number of Positive Samples`, big.mark = ",")
    select(filtered_data, Species, `Total Number of Samples`, `Total Number of Positive Samples`, `Percent Positive`, `Jeffreys Interval`)
  }, sanitize.text.function = function(x) x)
}

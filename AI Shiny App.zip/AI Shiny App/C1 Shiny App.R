#Hopefully and app for AI


setwd("C:/Users/DanielWade/Desktop/Uni/C1 Systematic Review")

# Load required libraries
library(shiny)
library(ggplot2)
library(dplyr)
library(readxl)
library(rsconnect)

Species_AI_Prevalence_and_Jeffries_Intervals <- read_excel("C:/Users/DanielWade/Desktop/Uni/C1 Systematic Review/Species AI Prevalence and Jeffries Intervals.xlsx")
View(Species_AI_Prevalence_and_Jeffries_Intervals)

data=as.data.frame(Species_AI_Prevalence_and_Jeffries_Intervals) 

# Define UI
ui <- fluidPage(
  tags$img(src = "https://findvectorlogo.com/wp-content/uploads/2019/04/university-of-hull-vector-logo.png", height = 100, width = 200),
  titlePanel("Avian Influenza prevalence rates and error in wild bird species by family"),
  sidebarLayout(
    sidebarPanel(
      selectInput("Family", "Select a bird family:", 
                  choices = unique(data$Family)),
    ),
    mainPanel(
      tableOutput("table"),
      plotOutput("graph"),
    )
  )
)

# Define server
server <- function(input, output) {
  data <- read_excel("C:/Users/DanielWade/Desktop/Uni/C1 Systematic Review/Species AI Prevalence and Jeffries Intervals.xlsx")
  output$graph <- renderPlot({
    filtered_data <- data %>% filter(Family == input$Family)
    ggplot(data = filtered_data, aes(x =`Percent Positive`, y = `Species (n)`, fill = `Species (n)`)) + 
      geom_boxplot()+
      geom_errorbar(aes(xmin = `Lower CI`, xmax =`Upper CI`, colour='grey'))+
      xlim(0,100)+
      theme_bw()+
      theme(legend.position = 'none')+
      xlab('Proportion positive and Jeffreys Interval')+ylab('Species (Number of Samples)')
  })
  
  output$table <- renderTable({
    filtered_data <- data %>% filter(Family == input$Family)
      select(filtered_data, Species,`Total Number of Samples`,`Total Number of Positive Samples`, `Percent Positive`,`Jeffreys Interval`)
  })
  
}

# Run the app
shinyApp(ui = ui, server = server)

#publish under shiny.io

rsconnect::setAccountInfo(name='dwade',
                          token='6F7994D98662BF85646C2736C1AB09C5',
                          secret='Jsn/ask1gcYiU5HH6cWsmlaKALfMn4eYbnYZUTMp')

rsconnect::deployApp(appDir='C:\\Users\\DanielWade\\Desktop\\Uni\\C1 Systematic Review\\C1 Shiny App.R',appName='AIprevalenceratesinwildbirds')

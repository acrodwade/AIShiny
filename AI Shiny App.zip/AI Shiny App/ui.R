# Define UI
library(plotly)
library(readxl)
ui <- fluidPage(
  tags$img(src = "https://findvectorlogo.com/wp-content/uploads/2019/04/university-of-hull-vector-logo.png", height = 100, width = 200),
  titlePanel("Avian Influenza prevalence rates and error in wild bird species"),
  h4("Developed by Daniel Wade, as part of his PhD thesis titled 'The Epizootiology of Avian Influenza in Wild Birds and Its Risk to the UK Poultry Sector' at the University of Hull. This app is a culmination of a systematic literature review."),
  fluidRow(
    column(
      width = 3,
      style = "padding: 5px;",  # Reduce the padding around the sidebarPanel
      selectInput("Family", "Select a bird family:", 
                  choices = unique(data$Family),
                  width = "100%"  # Adjust the width of the dropdown box
      )
    ),
    column(
      width = 9,
      tabsetPanel(
        tabPanel("Table", tableOutput("table")),
        tabPanel("Graph", div(
          style = "width: 100%; overflow-x: scroll;",
          plotlyOutput("graph")  # Use plotlyOutput to display the plot
        ))
      )
    )
  )
)
